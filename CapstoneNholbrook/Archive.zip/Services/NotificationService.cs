﻿using System;
namespace NHolbrookCapstone.Services
{
	public class NotificationService
	{
		public NotificationService()
		{
		}
	}
}

