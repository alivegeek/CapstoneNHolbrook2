﻿using System;
namespace NHolbrookCapstone.Services
{
	public class Service
	{
		public Service()
		{
		}
	}
}

