﻿using System;
namespace NHolbrookCapstone.ViewModels
{
	public class CalendarViewModel
	{
		public CalendarViewModel()
		{
		}
	}
}

