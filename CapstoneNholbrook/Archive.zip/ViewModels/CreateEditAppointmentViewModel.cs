﻿using System;
namespace NHolbrookCapstone.ViewModels
{
	public class CreateEditAppointmentViewModel
	{
		public CreateEditAppointmentViewModel()
		{
		}
	}
}

